package com.hdipo.live;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class MainActivity extends AppCompatActivity {

    private static final String APP_URL = "https://ais-pre-kagvgilpqnpwpkaqi7qqki-273113077839.asia-northeast1.run.app/?install=1";
    private static final String APP_HOST = "ais-pre-kagvgilpqnpwpkaqi7qqki-273113077839.asia-northeast1.run.app";

    private WebView webView;
    private ProgressBar progressBar;
    private SwipeRefreshLayout swipeRefresh;
    private long lastBackPressMs = 0L;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);
        swipeRefresh = findViewById(R.id.swipeRefresh);

        swipeRefresh.setColorSchemeColors(0xFF1D4ED8, 0xFF15803D);
        swipeRefresh.setOnRefreshListener(() -> {
            if (webView.getUrl() == null || webView.getUrl().startsWith("data:")) {
                webView.loadUrl(APP_URL);
            } else {
                webView.reload();
            }
        });

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(false);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress < 100) {
                    progressBar.setVisibility(View.VISIBLE);
                    progressBar.setProgress(newProgress);
                } else {
                    progressBar.setVisibility(View.GONE);
                    swipeRefresh.setRefreshing(false);
                }
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri == null) return false;
                String scheme = uri.getScheme() != null ? uri.getScheme().toLowerCase() : "";
                String host = uri.getHost() != null ? uri.getHost().toLowerCase() : "";
                String urlStr = uri.toString();

                // Open WhatsApp, phone, mail, intent, or external registrar/APK links outside WebView
                if (scheme.equals("whatsapp") || scheme.equals("tel") || scheme.equals("mailto")
                        || scheme.equals("intent") || host.contains("wa.me")
                        || host.contains("api.whatsapp.com") || urlStr.contains("/api/download/")) {
                    openExternalUri(uri);
                    return true;
                }

                // Keep main HD IPO domain inside app WebView; open external allotment/broker sites in Chrome
                if ((scheme.equals("https") || scheme.equals("http"))
                        && !APP_HOST.isEmpty()
                        && !host.equalsIgnoreCase(APP_HOST)
                        && !host.endsWith("." + APP_HOST)
                        && !host.contains("firebaseapp.com")
                        && !host.contains("accounts.google.com")) {
                    openExternalUri(uri);
                    return true;
                }

                return false;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    swipeRefresh.setRefreshing(false);
                    progressBar.setVisibility(View.GONE);
                    String offlineHtml = "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                            + "<style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;background:#f8fafc;color:#0f172a;text-align:center;padding:24px;}"
                            + ".card{background:#fff;border-radius:16px;padding:24px;box-shadow:0 6px 20px rgba(0,0,0,.08);max-width:340px;width:100%;}"
                            + "button{background:#1d4ed8;color:#fff;border:none;border-radius:10px;padding:12px 20px;font-weight:700;font-size:15px;margin-top:14px;width:100%;}</style></head>"
                            + "<body><div class='card'><h2>HD IPO Offline</h2><p>Internet connection check karein aur dobara try karein.</p>"
                            + "<button onclick=\"location.href='" + APP_URL + "'\">Retry Live Data</button></div></body></html>";
                    view.loadDataWithBaseURL(null, offlineHtml, "text/html", "UTF-8", null);
                }
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                openExternalUri(Uri.parse(url));
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack();
                } else {
                    long now = System.currentTimeMillis();
                    if (now - lastBackPressMs < 2000L) {
                        finish();
                    } else {
                        lastBackPressMs = now;
                        Toast.makeText(MainActivity.this, "Exit karne ke liye dobara Back dabayein", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        webView.loadUrl(APP_URL);
    }

    private void openExternalUri(Uri uri) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Browser ya app open nahi ho paya.", Toast.LENGTH_SHORT).show();
        }
    }
}
