========================================================
  HD IPO (v1.0) - REAL SIGNED base.apk BANANE KA TARIKA
========================================================

App URL: https://ais-pre-kagvgilpqnpwpkaqi7qqki-273113077839.asia-northeast1.run.app/?install=1
Package ID: com.hdipo.live
Version: v1.0

--------------------------------------------------------
TARIKA 1: FREE CLOUD AUTO-BUILD (BINA ANDROID STUDIO KE)
--------------------------------------------------------
1. github.com par free account kholein aur "New Repository" banayein (naam: hd-ipo-apk, Public rakhein).
2. Is ZIP file ko unzip karke saari files us repo mein upload karein (ya git push karein).
3. GitHub repo mein upar "Actions" tab par click karein — 90 second mein signed "HD-IPO-v1.0-base.apk" automatically ban jayegi!
4. Repo ke "Releases" section mein aapko direct .apk download link mil jayegi:
   https://github.com/<your-username>/hd-ipo-apk/releases/latest/download/base.apk
5. Us link ko HD IPO app -> 3-Line Menu -> Settings -> "Save APK Link & Version" mein paste karein, ya seedha "Upload base.apk" button se upload kar dein!

--------------------------------------------------------
TARIKA 2: ANDROID STUDIO SE (LAPTOP / PC PAR)
--------------------------------------------------------
1. Android Studio kholein -> "Open" -> is unzipped folder ko select karein.
2. Menu mein Build -> Build Bundle(s) / APK(s) -> Build APK(s) par click karein.
3. app/build/outputs/apk/debug/app-debug.apk ko rename karke base.apk bana lein aur HD IPO Settings mein upload kar dein.
